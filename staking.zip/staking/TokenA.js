var contract = null;
var account = null;
var web3 = null;
const contractAddress = "0x573AEA0a1097CC6EF7Ee736890D7Cf8F57E40487";
var abi = [
    [
        {
            "inputs": [
                {
                    "internalType": "string",
                    "name": "_Tname",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "_Tsymbol",
                    "type": "string"
                },
                {
                    "internalType": "uint256",
                    "name": "_TtotalSupply",
                    "type": "uint256"
                },
                {
                    "internalType": "uint256",
                    "name": "_Tdecimal",
                    "type": "uint256"
                }
            ],
            "stateMutability": "nonpayable",
            "type": "constructor"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "owner",
                    "type": "address"
                },
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "spender",
                    "type": "address"
                },
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "value",
                    "type": "uint256"
                }
            ],
            "name": "Approval",
            "type": "event"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "spender",
                    "type": "address"
                },
                {
                    "internalType": "uint256",
                    "name": "amount",
                    "type": "uint256"
                }
            ],
            "name": "approve",
            "outputs": [
                {
                    "internalType": "bool",
                    "name": "",
                    "type": "bool"
                }
            ],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "amount",
                    "type": "uint256"
                }
            ],
            "name": "burn",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "amount",
                    "type": "uint256"
                }
            ],
            "name": "mint",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "recipient",
                    "type": "address"
                },
                {
                    "internalType": "uint256",
                    "name": "_amount",
                    "type": "uint256"
                }
            ],
            "name": "transfer",
            "outputs": [
                {
                    "internalType": "bool",
                    "name": "",
                    "type": "bool"
                }
            ],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "from",
                    "type": "address"
                },
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "to",
                    "type": "address"
                },
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "value",
                    "type": "uint256"
                }
            ],
            "name": "Transfer",
            "type": "event"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "sender",
                    "type": "address"
                },
                {
                    "internalType": "address",
                    "name": "recipient",
                    "type": "address"
                },
                {
                    "internalType": "uint256",
                    "name": "amount",
                    "type": "uint256"
                }
            ],
            "name": "transferFrom",
            "outputs": [
                {
                    "internalType": "bool",
                    "name": "",
                    "type": "bool"
                }
            ],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "_decimal",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "_name",
            "outputs": [
                {
                    "internalType": "string",
                    "name": "",
                    "type": "string"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "_symbol",
            "outputs": [
                {
                    "internalType": "string",
                    "name": "",
                    "type": "string"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "_totalSupply",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "_owner",
                    "type": "address"
                },
                {
                    "internalType": "address",
                    "name": "_spender",
                    "type": "address"
                }
            ],
            "name": "allowance",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "",
                    "type": "address"
                },
                {
                    "internalType": "address",
                    "name": "",
                    "type": "address"
                }
            ],
            "name": "allowed",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "_owner",
                    "type": "address"
                }
            ],
            "name": "balanceOf",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "",
                    "type": "address"
                }
            ],
            "name": "balances",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "decimals",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "name",
            "outputs": [
                {
                    "internalType": "string",
                    "name": "",
                    "type": "string"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "symbol",
            "outputs": [
                {
                    "internalType": "string",
                    "name": "",
                    "type": "string"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "totalSupply",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        }
    ]
];
async function initWeb3() {
    // New web3 provider
      if (window.ethereum) {
       //   web3 = new Web3(ethereum);
          try {
              // ask user for permission
              await ethereum.enable();
              // user approved permission
          } catch (error) {
              // user rejected permission
              console.log('user rejected permission');
          }
      }
      // Old web3 provider
      else if (window.web3) {
          web3 = new Web3(web3.currentProvider);
          // no need to ask for permission
      }
      // No web3 provider
      else {
          console.log('No web3 provider detected');
      }
    }
window.addEventListener('load', async () => {
    await initWeb3();
    console.log (window.web3.currentProvider);
    //contract instance
    contract = new web3.eth.Contract(abi, contractAddress);
    web3.eth.getAccounts(function(err, accounts) {
    if (err != null) {
        alert("Error retrieving accounts.");
        return;
    }
    if (accounts.length == 0) {
        alert("No account found! Make sure the Ethereum client is configured properly.");
        return;
    }
    account = accounts[0];
    console.log('Account: ' + account);
    web3.eth.defaultAccount = account;
    });
});
const Name = async () => {
    var _name = await contract.methods.name().call();
    document.getElementById("demo1").innerHTML=_name;
}
const symbol = async () => {
    var _symbol = await contract.methods.symbol().call();
    document.getElementById("demo2").innerHTML=_symbol;
}
const decimal = async () => {
    var _decimal = await contract.methods.decimals().call();
    document.getElementById("demo3").innerHTML=_decimal;
}
const totalSupply = async () => {
    var totalSupply = await contract.methods.totalSupply().call();
    document.getElementById("demo4").innerHTML=totalSupply;
}
const checkBalance = async () => {
    var address = document.getElementById("address1").value;                        
    var balance = await contract.methods.balanceOf(address).call() ;
    console.log(balance);
    document.getElementById("demo5").innerHTML=balance;
}
const mint = async () => {
  var amount  = document.getElementById("amount1").value;
  var fromAddress=account; 
  var nonce = await web3.eth.getTransactionCount(fromAddress);
  nonce = web3.utils.toHex(nonce);
  var gasPrice = await web3.eth.getGasPrice();
  gasPrice=web3.utils.toHex(gasPrice);
  var gasLimit = web3.utils.toHex('1000000');
  amount  = web3.utils.toWei(amount, "ether");
  var data = await contract.methods.mint(amount).send({
    from: fromAddress,
    to: contractAddress,
    nonce: nonce,
    gasLimit: gasLimit,
    gasPrice: gasPrice
  });
  console.log(data);
}     
const burn = async () => {
  var amount  = document.getElementById("amount10").value;
  var fromAddress=account; 
  var nonce = await web3.eth.getTransactionCount(fromAddress);
  nonce = web3.utils.toHex(nonce);
  var gasPrice = await web3.eth.getGasPrice();
  gasPrice=web3.utils.toHex(gasPrice);
  var gasLimit = web3.utils.toHex('1000000');
  amount  = web3.utils.toWei(amount, "ether");
  var data = await contract.methods.burn(amount).send({
    from: fromAddress,
    to: contractAddress,
    nonce: nonce,
    gasLimit: gasLimit,
    gasPrice: gasPrice
  });
  console.log(data);
}
const transfer = async () => {
    var address = document.getElementById("address2").value;
    var amount  = document.getElementById("amount2").value;
    var fromAddress = account;
    var toAddress = address;
    var nonce = await web3.eth.getTransactionCount(fromAddress);
    nonce = web3.utils.toHex(nonce);
    var gasPrice = await web3.eth.getGasPrice();
    gasPrice=web3.utils.toHex(gasPrice);
    var gasLimit = web3.utils.toHex('1000000');
    amount = web3.utils.toWei(amount, "ether");
    var data = await contract.methods.transfer(toAddress,amount).send({
      from: fromAddress,
      to: contractAddress,
      nonce: nonce,
      gasLimit: gasLimit,
      gasPrice: gasPrice
    });
    console.log(data);
}

const approve = async () => {
  var address = document.getElementById("address3").value;
  var amount  = document.getElementById("amount3").value;
  var fromAddress = account;  
  var toAddress = address;
  var nonce = await web3.eth.getTransactionCount(fromAddress);
  nonce = web3.utils.toHex(nonce);
  var gasPrice = await web3.eth.getGasPrice();
  gasPrice=web3.utils.toHex(gasPrice);
  var gasLimit = web3.utils.toHex('1000000');
  amount  = web3.utils.toWei(amount, "ether");
  var data = await contract.methods.approve(toAddress, amount).send({
    from :fromAddress,
    to: contractAddress,
    nonce: nonce,
    gasLimit: gasLimit,
    gasPrice: gasPrice
  });
  console.log(data);
}
const allowance = async () => {
  var address1 = document.getElementById("address4").value;
  var address2 = document.getElementById("address5").value;
  var allowed = await contract.methods.allowance(address1,address2).call();
  document.getElementById("demo11").innerHTML=allowed;
}
const transferFrom = async () => {
  var address1 = document.getElementById("address6").value;
  var address2 = document.getElementById("address7").value;
  var amount  = document.getElementById("amount4").value;
  var fromAddress = address1;
  var approvedAddress = account; //approved
  var receiverAddress = address2;
  var nonce = await web3.eth.getTransactionCount(approvedAddress);
  nonce = web3.utils.toHex(nonce);
  var gasPrice = await web3.eth.getGasPrice();
  gasPrice=web3.utils.toHex(gasPrice);
  var gasLimit = web3.utils.toHex('1000000');
  amount  = web3.utils.toWei(amount, "ether");
  var data = await contract.methods.transferFrom(fromAddress, receiverAddress,amount).send({
    from :approvedAddress,
    to: contractAddress,
    nonce: nonce,
    gasLimit: gasLimit,
    gasPrice: gasPrice
  });
  console.log(data);
}