var contract = null;
// Accounts
var account = null;
var web3 = null;
// contractAddress and abi are setted after contract deploy
const contractAddress = '0x66eaba3Ff00286A75084D8654E26421e3904ff4b';
var abi = [
    [
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "owner",
                    "type": "address"
                },
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "spender",
                    "type": "address"
                },
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "value",
                    "type": "uint256"
                }
            ],
            "name": "Approval",
            "type": "event"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "from",
                    "type": "address"
                },
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "to",
                    "type": "address"
                },
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "value",
                    "type": "uint256"
                }
            ],
            "name": "Transfer",
            "type": "event"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "owner",
                    "type": "address"
                },
                {
                    "internalType": "address",
                    "name": "spender",
                    "type": "address"
                }
            ],
            "name": "allowance",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "spender",
                    "type": "address"
                },
                {
                    "internalType": "uint256",
                    "name": "amount",
                    "type": "uint256"
                }
            ],
            "name": "approve",
            "outputs": [
                {
                    "internalType": "bool",
                    "name": "",
                    "type": "bool"
                }
            ],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "account",
                    "type": "address"
                }
            ],
            "name": "balanceOf",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "totalSupply",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "recipient",
                    "type": "address"
                },
                {
                    "internalType": "uint256",
                    "name": "amount",
                    "type": "uint256"
                }
            ],
            "name": "transfer",
            "outputs": [
                {
                    "internalType": "bool",
                    "name": "",
                    "type": "bool"
                }
            ],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "address",
                    "name": "sender",
                    "type": "address"
                },
                {
                    "internalType": "address",
                    "name": "recipient",
                    "type": "address"
                },
                {
                    "internalType": "uint256",
                    "name": "amount",
                    "type": "uint256"
                }
            ],
            "name": "transferFrom",
            "outputs": [
                {
                    "internalType": "bool",
                    "name": "",
                    "type": "bool"
                }
            ],
            "stateMutability": "nonpayable",
            "type": "function"
        }
    ]
  ];
   
// New web3 provider
//async function initWeb3() {
    // New web3 provider
      if (window.ethereum) {
          web3 = new Web3(ethereum);
          try {
              // ask user for permission
              await ethereum.enable();
              // user approved permission
          } catch (error) {
              // user rejected permission
              console.log('user rejected permission');
          }
      }
      // Old web3 provider
      else if (window.web3) {
          web3 = new Web3(web3.currentProvider);
          // no need to ask for permission
      }
      // No web3 provider
      else {
          console.log('No web3 provider detected');
      }


window.addEventListener('load', async () => {
  await initWeb3();
  console.log (window.web3.currentProvider);
  //contract instance
  contract = new web3.eth.Contract(abi, contractAddress);
  web3.eth.getAccounts(function(err, accounts) {
    if (err != null) {
      alert("Error retrieving accounts.");
      return;
    }
    if (accounts.length == 0) {
      alert("No account found! Make sure the Ethereum client is configured properly.");
      return;
    }
    account = accounts[0];
    console.log('Account: ' + account);
    web3.eth.defaultAccount = account;
  });
});

  
  const Stake = async () => {  
    var amount = document.getElementById("address1").value;
    var nonce = await web3.eth.getTransactionCount('0xa2f78E5763934dA522E095a93C20dCB4975c3218');
    nonce = web3.utils.toHex(nonce);
    var gasPrice = await web3.eth.getGasPrice();
    gasPrice=web3.utils.toHex(gasPrice);
    var gasLimit = web3.utils.toHex('1000000');
    amount = web3.utils.toWei(1, "ether");
    var data = await contract.methods.stake(amount).send({
        from: fromAddress,
        to: contractAddress,
        nonce: nonce,
        gasLimit: gasLimit,
        gasPrice: gasPrice
      });
      console.log(data);
}
     

  const withdraw = async () => {
    var amount = document.getElementById("address2").value;
    var nonce = await web3.eth.getTransactionCount('0xe28Ecd379C61a40F094d80cAf7F7cf44B4605f24');
    nonce = web3.utils.toHex(nonce);
    var gasPrice = await web3.eth.getGasPrice();
    gasPrice=web3.utils.toHex(gasPrice);
    var gasLimit = web3.utils.toHex('1000000');
    amount = web3.utils.toWei(1, "ether");
    var data = await contract.methods.stake(amount).send({
        from: fromAddress,
        to: contractAddress,
        nonce: nonce,
        gasLimit: gasLimit,
        gasPrice: gasPrice
      });
      console.log(data);
} 

  const getReward = async () => {
    var amount = document.getElementById("address1").value;
    var nonce = await web3.eth.getTransactionCount('0xa2f78E5763934dA522E095a93C20dCB4975c3218');
    nonce = web3.utils.toHex(nonce);
    var gasPrice = await web3.eth.getGasPrice();
    gasPrice=web3.utils.toHex(gasPrice);
    var gasLimit = web3.utils.toHex('1000000');
    amount = web3.utils.toWei(0.1, "ether");
    var data = await contract.methods.stake(amount).send({
        from: fromAddress,
        to: contractAddress,
        nonce: nonce,
        gasLimit: gasLimit,
        gasPrice: gasPrice
      });
      console.log(data);
} 